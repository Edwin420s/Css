
document.getElementById("clickBtn").addEventListener("click", () => {
  alert("Button was clicked!");
});

document.getElementById("keyInput").addEventListener("keydown", (e) => {
  console.log("Key pressed:", e.key);
});

document.getElementById("secretBtn").addEventListener("dblclick", () => {
  document.getElementById("secretMessage").textContent = "🎉 You found the secret!";
});

document.getElementById("colorChanger").addEventListener("click", function () {
  this.style.backgroundColor = this.style.backgroundColor === "green" ? "purple" : "green";
});

const images = [
  "https://via.placeholder.com/300x200/ff7f7f",
  "https://via.placeholder.com/300x200/7fbfff",
  "https://via.placeholder.com/300x200/7fff7f"
];
let index = 0;

function showImage() {
  document.getElementById("galleryImg").src = images[index];
}

function prevImage() {
  index = (index - 1 + images.length) % images.length;
  showImage();
}

function nextImage() {
  index = (index + 1) % images.length;
  showImage();
}

function openTab(tabId) {
  const contents = document.querySelectorAll(".tabContent");
  contents.forEach(el => el.style.display = "none");
  document.getElementById(tabId).style.display = "block";
}

const form = document.getElementById("form");
const password = document.getElementById("password");
const feedback = document.getElementById("feedback");

password.addEventListener("input", () => {
  if (password.value.length < 8) {
    feedback.textContent = "Password too short!";
    feedback.style.color = "red";
  } else {
    feedback.textContent = "✅ Looks good!";
    feedback.style.color = "green";
  }
});

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value;
  const pass = password.value;

  if (!name || !email || !pass) {
    alert("All fields are required.");
    return;
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    alert("Invalid email format.");
    return;
  }

  if (pass.length < 8) {
    alert("Password must be at least 8 characters.");
    return;
  }

  alert("Form submitted successfully! 🎉");
});
